import {BrowserRouter,Routes,Route} from "react-router-dom";
import './App.css';
import Home from './pages/homepage';
import Demo from './pages/demo';
import Header from './pages/header';
import Item from './pages/content';
import CarouselFadeExample from './pages/Cara';
import Footer from "./pages/footer";
import Test from "./pages/test";
import Break from "./pages/break";
import ScrollToTop from "./utils/ScrollToTop"
import ProductListPage from "./pages/ProductListPage";
import ProductDetailsPage from "./pages/ProductDetailsPage";
function App() {
  // document.getElementById("root").style.border="10px solid red";
  return (
    <>
    <BrowserRouter>
    <Header/>
    <ScrollToTop/>
    <ProductListPage/>
    <ProductDetailsPage/>
    <Routes>
    {/* <Route path="/product" element={<ProductList/>}/> */}
    
    </Routes>
    <Break />
    </BrowserRouter>
    <Footer/>
    </>
  );
}

export default App;
