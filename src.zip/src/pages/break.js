import React from "react";
function Break(){
    console.log("Break called")
return(
<div className="App">
<p style={{padding:"100px", margin:"10px"}}><br></br></p>
</div>

)
}
export default Break