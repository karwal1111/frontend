import {Nav, Navbar, NavDropdown,Container,Form, Button, Badge} from 'react-bootstrap';
function Header() {
  return (
   <Navbar style={{ backgroundColor: '#F0E68C' }} > 
   {/*  */}
      <Container fluid>
        <Navbar.Brand href="#"><img
          src="brand.png"
          alt="Krishna Jewellers Logo"
          width="70" // adjust width as needed
          height="70" // adjust height as needed
          className="d-inline-block align-top"
          style={{ marginRight: '10px' }} // add space between image and text
        />Krishna Jewellers</Navbar.Brand>
        <Navbar.Toggle aria-controls="navbarScroll" />
        <Navbar.Collapse id="navbarScroll">
          <Nav
            className="me-auto my-2 my-lg-0"
            style={{ maxHeight: '100px' }}
            navbarScroll
          >
            <Nav.Link href="/">Home</Nav.Link>
            {/* <Nav.Link href="#action2">Types</Nav.Link> */}
            <NavDropdown title="Jewellery" id="navbarScrollingDropdown" data-bs-theme="dark" >
            {/* <Badge bg="primary">Primary</Badge> */}
              <NavDropdown.Item href="#action3">Gold Sets</NavDropdown.Item>
              <NavDropdown.Item href="#action4">Rings</NavDropdown.Item>
              <NavDropdown.Item href="#action3">Bracelets</NavDropdown.Item>
              <NavDropdown.Item href="#action4">bangles</NavDropdown.Item>
              <NavDropdown.Item href="#action3">Diamonds</NavDropdown.Item>
              <NavDropdown.Item href="#action4">Name lockets</NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item href="#action5">
                Something else here
              </NavDropdown.Item>
            </NavDropdown>
            <Nav.Link href="#" disabled>
              Link
            </Nav.Link>
          </Nav>
          <Form className="d-flex">
            <Form.Control
              type="search"
              placeholder="Search"
              className="me-2"
              aria-label="Search"
            />
            <Button variant="outline-success">Search</Button>
          </Form>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default Header;