import Header from "./header";
import Footer from "./footer";
import CarouselFadeExample from "./Cara";
const ProductList=()=>{
return(<>
    <h1>This is Productlist page</h1>
</>
)
}

export default ProductList