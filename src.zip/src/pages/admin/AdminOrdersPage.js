const AdminOrdersPage = () => {
  return <p>This is an orders page</p>;
};

export default AdminOrdersPage;

