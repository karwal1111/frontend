const AdminCreateProductPage = () => {
  return <p>This is a create product page</p>;
};

export default AdminCreateProductPage;

