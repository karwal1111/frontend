const AdminUsersPage = () => {
  return <p>This is a users page</p>;
};

export default AdminUsersPage;

