const AdminOrderDetailsPage = () => {
  return <p>This is a order details page</p>;
};

export default AdminOrderDetailsPage;

