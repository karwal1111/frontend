const AdminEditProductPage = () => {
  return <p>This is an edit product page</p>;
};

export default AdminEditProductPage;

